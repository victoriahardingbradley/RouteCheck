# trial_0044

- Route: RouteID_001b4ee3-c4f2-467f-932b-c85524d1021f
- Condition: Combined
- Simulated degraded share: 30%
- Random seed: 7
- Countermeasure: on

Reference replay duration: 495.0 minutes.
Stops scheduled: 141 of 141.
Compute time: 0.122651 seconds. Human review time: not measured.
Changed directed edges: 10184 of 20022. Mean simulated edge age: 36.00 days.
Repairs: 10045. True positives: 10037. False positives: 8. Missed defects: 147. True negatives: 9830.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.