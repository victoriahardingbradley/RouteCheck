# trial_0124

- Route: RouteID_001b4ee3-c4f2-467f-932b-c85524d1021f
- Condition: Low quality only
- Simulated degraded share: 10%
- Random seed: 43
- Countermeasure: on

Reference replay duration: 482.8 minutes.
Stops scheduled: 141 of 141.
Compute time: 0.124147 seconds. Human review time: not measured.
Changed directed edges: 2002 of 20022. Mean simulated edge age: 0.00 days.
Repairs: 1942. True positives: 1926. False positives: 16. Missed defects: 76. True negatives: 18004.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.