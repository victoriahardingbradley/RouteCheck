# trial_0310

- Route: RouteID_001948e9-4675-486d-9ec5-912fd8e0770f
- Condition: Stale only
- Simulated degraded share: 40%
- Random seed: 7
- Countermeasure: on

Reference replay duration: 550.9 minutes.
Stops scheduled: 127 of 127.
Compute time: 0.104973 seconds. Human review time: not measured.
Changed directed edges: 6502 of 16256. Mean simulated edge age: 60.00 days.
Repairs: 6502. True positives: 6502. False positives: 0. Missed defects: 0. True negatives: 9754.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.