# trial_0466

- Route: RouteID_0076d53c-6bfa-4e22-b39e-08769fb8e4d3
- Condition: Low quality only
- Simulated degraded share: 40%
- Random seed: 7
- Countermeasure: on

Reference replay duration: 488.9 minutes.
Stops scheduled: 129 of 129.
Compute time: 0.114793 seconds. Human review time: not measured.
Changed directed edges: 6708 of 16770. Mean simulated edge age: 0.00 days.
Repairs: 6565. True positives: 6553. False positives: 12. Missed defects: 155. True negatives: 10050.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.