# trial_0426

- Route: RouteID_001948e9-4675-486d-9ec5-912fd8e0770f
- Condition: Combined
- Simulated degraded share: 20%
- Random seed: 43
- Countermeasure: on

Reference replay duration: 558.5 minutes.
Stops scheduled: 127 of 127.
Compute time: 0.103978 seconds. Human review time: not measured.
Changed directed edges: 5811 of 16256. Mean simulated edge age: 18.00 days.
Repairs: 5720. True positives: 5720. False positives: 0. Missed defects: 91. True negatives: 10445.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.