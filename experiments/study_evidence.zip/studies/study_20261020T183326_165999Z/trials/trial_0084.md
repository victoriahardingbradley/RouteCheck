# trial_0084

- Route: RouteID_001b4ee3-c4f2-467f-932b-c85524d1021f
- Condition: Low quality only
- Simulated degraded share: 50%
- Random seed: 19
- Countermeasure: on

Reference replay duration: 504.5 minutes.
Stops scheduled: 141 of 141.
Compute time: 0.126170 seconds. Human review time: not measured.
Changed directed edges: 10011 of 20022. Mean simulated edge age: 0.00 days.
Repairs: 9591. True positives: 9587. False positives: 4. Missed defects: 424. True negatives: 10007.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.