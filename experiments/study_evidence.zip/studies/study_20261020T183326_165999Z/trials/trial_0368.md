# trial_0368

- Route: RouteID_001948e9-4675-486d-9ec5-912fd8e0770f
- Condition: Low quality only
- Simulated degraded share: 30%
- Random seed: 19
- Countermeasure: on

Reference replay duration: 566.1 minutes.
Stops scheduled: 127 of 127.
Compute time: 0.103524 seconds. Human review time: not measured.
Changed directed edges: 4877 of 16256. Mean simulated edge age: 0.00 days.
Repairs: 4744. True positives: 4744. False positives: 0. Missed defects: 133. True negatives: 11379.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.