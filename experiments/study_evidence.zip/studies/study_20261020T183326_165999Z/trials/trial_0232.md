# trial_0232

- Route: RouteID_00b8cd9c-613a-4519-b3fd-2b7174f1cff3
- Condition: Combined
- Simulated degraded share: 10%
- Random seed: 19
- Countermeasure: on

Reference replay duration: 477.2 minutes.
Stops scheduled: 79 of 79.
Compute time: 0.035927 seconds. Human review time: not measured.
Changed directed edges: 1208 of 6320. Mean simulated edge age: 6.00 days.
Repairs: 1186. True positives: 1186. False positives: 0. Missed defects: 22. True negatives: 5112.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.