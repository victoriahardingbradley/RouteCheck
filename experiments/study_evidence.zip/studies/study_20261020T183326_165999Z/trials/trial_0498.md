# trial_0498

- Route: RouteID_0076d53c-6bfa-4e22-b39e-08769fb8e4d3
- Condition: Stale only
- Simulated degraded share: 20%
- Random seed: 19
- Countermeasure: on

Reference replay duration: 423.9 minutes.
Stops scheduled: 129 of 129.
Compute time: 0.106687 seconds. Human review time: not measured.
Changed directed edges: 3354 of 16770. Mean simulated edge age: 18.00 days.
Repairs: 3363. True positives: 3354. False positives: 9. Missed defects: 0. True negatives: 13407.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.