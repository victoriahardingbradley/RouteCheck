# trial_0016

- Route: RouteID_001b4ee3-c4f2-467f-932b-c85524d1021f
- Condition: Stale only
- Simulated degraded share: 10%
- Random seed: 7
- Countermeasure: on

Reference replay duration: 458.5 minutes.
Stops scheduled: 141 of 141.
Compute time: 0.121306 seconds. Human review time: not measured.
Changed directed edges: 2002 of 20022. Mean simulated edge age: 6.00 days.
Repairs: 2017. True positives: 2002. False positives: 15. Missed defects: 0. True negatives: 18005.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.