# trial_0178

- Route: RouteID_00b8cd9c-613a-4519-b3fd-2b7174f1cff3
- Condition: Low quality only
- Simulated degraded share: 40%
- Random seed: 7
- Countermeasure: on

Reference replay duration: 487.5 minutes.
Stops scheduled: 79 of 79.
Compute time: 0.036867 seconds. Human review time: not measured.
Changed directed edges: 2528 of 6320. Mean simulated edge age: 0.00 days.
Repairs: 2402. True positives: 2402. False positives: 0. Missed defects: 126. True negatives: 3792.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.