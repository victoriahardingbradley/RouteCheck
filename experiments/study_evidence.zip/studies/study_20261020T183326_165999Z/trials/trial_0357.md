# trial_0357

- Route: RouteID_001948e9-4675-486d-9ec5-912fd8e0770f
- Condition: Stale only
- Simulated degraded share: 40%
- Random seed: 19
- Countermeasure: off

Reference replay duration: 589.6 minutes.
Stops scheduled: 127 of 127.
Compute time: 0.056380 seconds. Human review time: not measured.
Changed directed edges: 6502 of 16256. Mean simulated edge age: 60.00 days.
Repairs: 0. True positives: 0. False positives: 0. Missed defects: 6502. True negatives: 9754.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.