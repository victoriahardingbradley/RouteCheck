# trial_0364

- Route: RouteID_001948e9-4675-486d-9ec5-912fd8e0770f
- Condition: Low quality only
- Simulated degraded share: 10%
- Random seed: 19
- Countermeasure: on

Reference replay duration: 544.8 minutes.
Stops scheduled: 127 of 127.
Compute time: 0.101790 seconds. Human review time: not measured.
Changed directed edges: 1626 of 16256. Mean simulated edge age: 0.00 days.
Repairs: 1575. True positives: 1575. False positives: 0. Missed defects: 51. True negatives: 14630.

Read the JSON beside this file for the full order, replay arrivals, model fingerprint and flagged edges. Compare against the matching route, condition, stage and seed with the other countermeasure setting.
The modification log records each original and changed value. Unprotected runs do not activate a detector, so their missed-defect count is not an evaluation of the protected detector.
Lower replay duration is the primary objective. Negative recovery in paired_comparisons.csv means that repair made the result worse. Historical replay estimates are not fresh ground truth.